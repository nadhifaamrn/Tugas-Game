#include <stdio.h>

static void proof(){
	printf("Note: Klik enter untuk melanjutkan misi....\n");
	puts("Saatnya Mencari Bukti.....");
	puts("Peta Desa");
	puts("======================================================================================================================");
	
	
	puts("				||Rumah Dokter||");
	puts("||Balai Desa||");
	puts("		||Rumah V si Kaya||");
	printf("						||Bioskop||");
	printf("	||Arkade||");
	printf("	||Studio Foto||");
	puts("	||Salon||");
	
	puts("======================================================================================================================");
	
	puts("Kunjungan pertama anda ke Salon Barber Hope, terletak di jalan masuk desa.");
	puts("Semua orang sedang menelusuri Salon Barber Hope......");
	getch();
	
	puts("Ohhhh??.... Apaa ituuuu?!!!!");
	getch();
	
	puts("Chief Park menemukann sesuatuuu.....");
	getch();
	
	puts("DARAH??!!!......");
	getch();
	
	puts("Kenapa ada darah dihanduk?");
	getch();
	
	puts("Barber Hope menjelaskan alasannya");
	puts("\"Saat aku latihan untuk kompetisi aku terluka, nodanya tidak bisa hilang\"");
	getch();
	
	puts("---------------------------------------------------------------------------------------------------------------------");
	puts("\n#Bukti_BarberHope: Handuk yang basah dengan darah luka saat berlatih kompetisi salon");
	puts("Alibi: Aku terluka saat sedang latihan\n");

	puts("---------------------------------------------------------------------------------------------------------------------");
	getch();
		
	puts("Barber Hope dicurigai semua orang........");
	getch();
	
	puts("Chief Park: \"Kamu bilang kalau kamu ikut kompetisi, kenapa kamu ikut kompetisi?\"");
	getch();
	puts("Barber Hope menjelaskan alasannya");
	puts("\"Bukankah mimpi semua ahli kecantikan adalah sesekali mengikuti kompetisi seperti itu dan mendapatkan juara 1?\"");
	getch();
	
	
	puts("---------------------------------------------------------------------------------------------------------------------");

	puts("\nAlibi: Mimpi setiap ahli kecantikan adalah juara 1 di kompetisi salon\n");

	puts("---------------------------------------------------------------------------------------------------------------------\n");
	getch();
	
	puts("Bagaimana menurutmu, Detektif?\n");
	getch();
	
	puts("Photograper: \"Kapan kejadiannya\"");
	puts("Barber Hope: \"Aku latihan sekitar jam 12 siang\"");
	puts("[setelah menutup salon, dia berlatih dan terluka]");
	puts("[Photograper datang ke salon, tapi tutup]");
	getch();
	
	puts("Ticket Seller menemukan satu bukti di bawah tikar");
	
	
	puts("-----------------------------------------------------------------------------------------------------------------------\n");
	puts("#Bukti_BarberHope. Diarynya. Juara 1 di kompetisi salon saat hari kejadian?");
	puts("------------------------------------------------------------------------------------------------------------------------\n");
	puts("Ticket Seller: \" Ada satu hal yang belum saya tanyakan. Saat ada mati lampu jam 7 malam, apa yang kamu lakukann\"");
	puts("Barber Hope: \"Saat ada mati lampu, aku mendatangi fotografer Suga, tapi daia tidak ada. Saat itu aku menang juara 1 di kompetisi,");
	puts("	      Kamu tahu kalau kita teman baik, kan? Aku ingin menikmati momen itu dengan mengadakan pesta. Aku ingin berfoto");
	puts("	      dengannya sambil memegang penghargaanku, tapi dia tidak ada di sana\"");
	getch();
	
	
	puts("Photograper: \"Saat dia datang, aku sedang menonton berita di rumah");
	puts("Barber Hope: \"Bukankah kamu mengunjungiku?\"");
	puts("Photograper: \"Jam 7 malam aku menonton berita, sekitar jam 9 malam, aku ingin bertemu dengannya, jadi aku datang ke pangkas rambut,");
	puts("	      tetapi lampunya mati.\"");
	puts("BarberHope: \"Aku pergi mendatangimu, tiba-tiba ada pemandaman listrik");
	getch();
	
	puts("\n[Terdapat sepasang sarung tangan bekas pakai di atas sepeda]");
	puts("Oh... Ada sepotong kertas juga...");
	puts("Penilaian warga desa tentangnya: \"Dialah sumber informasinya, tetapi aku tidak tahu samasekali dari mana informasi-informasi itu berasal\"");
	getch();
	
	puts("\n======================================================================================================================");
	puts("\nMari pindah ke tempat selanjutnya, Studio Photograper");
	puts("======================================================================================================================\n");
	getch();
	
	puts("[Menmukan bukti di saku jaket]");
	puts("Sepertinya, terkadang dia pergi untuk mengambil foto di sekitar tugu ARMY");
	getch();
	
	puts("Alibi: Aku ingin memotret Tugu ARMY yang merupakan Tugu keberuntungan");
	puts("#Bukti Swafoto dengan tugu ARMY yang baik-baik saja");\
	getch();

	puts("\n======================================================================================================================");
	puts("\nMari pindah ke tempat selanjutnya, Arcade");
	puts("======================================================================================================================\n");
	getch();
	
	puts("Gamer: \"Belakangan ini Chief Park memecahkan rekorku dalam bermain game. Aku harus mengembalikan posisiku.");
	puts("	Jam 5 sore aku pergi ke tugu ARMY untuk membuat permohonan agar mengembalikan posisi pertamanya  ");
	
	puts("\"Tak perlu dibicarakan lagi. Dia menghabiskan semua listrik di desa ini.\"");
	getch();
	
	puts("#Bukti sendal yang di pakai melihat tugu ARMY sama dengan jejak kaki pelaku");
	
	puts("\n======================================================================================================================");
	puts("\nMari pindah ke tempat selanjutnya, Bioskop");
	puts("======================================================================================================================\n");
	getch();
	
	puts("\n#Bukti_TicketSeller: \"Suatu hari, warga desa sebelah berkunjung untuk menanyakan dia ikut audisi atau tidak.\"");
	puts("Alibi: Hari kejadian itu, aku sedang mengikuti audisi untuk film \"Boy With Luv\" jam 7."); getch();
	puts("\n#Bukti_TicketSeller: Ditemukan jam tangan yang waktunya berhenti pada pukul 7");
	puts("Alibi: Aku mengatur jam untuk terus pada pukul 7 agar bisa bangun dan bekerja tepat waktu."); getch();
	
	puts("\n======================================================================================================================");
	puts("\nMari pindah ke tempat selanjutnya, Rumah milik Rich Guy");
	puts("======================================================================================================================\n");
	getch();
	
	puts("\n#Bukti_RichGuy: Ditemukan buku harian yang berisi: \"Berat tugu Army setara berat 2 manusia\""); getch();
	puts("TicketSeller: \"Apakah kau bermaksud mengangkat dan membawa tugu Armynya?\""); getch();
	puts("\n#Bukti_RichGuy: Terdapat peta lokasi tugu Army di rumah milik RIch Guy. Apakah itu benar-benar harta karun?"); getch();
	
	puts("\n======================================================================================================================");
	puts("\nMari pindah ke tempat selanjutnya, Rumah Dokter");
	puts("======================================================================================================================\n");
	getch();	
	
	puts("Chief Park menyewa kamar di rumah seorang dokter"); getch();
	
	puts("\n#Bukti_ChiefPark: Ditemukan buku harian yang berisi: jadwal bus antara desa biru dan desa BTS. Naik bus jam 7\n"); getch();
	puts("Ticket seller: \"Aku melihatmu di halte jam 6, apakah kau menunggu selama 1 jam?\"");
	puts("Chief Park: \"Aku keluar jam 6 dan pergi ke desa biru dnegan bis\""); getch();
	puts("\n#Bukti_ChiefPark: Ditemukan Penelitian tugu army: berat, bercahaya di malam hari, dan hanya penduduk asli yang mengetahui letaknya.");
	puts("Alibi: aku hanya ingin tahu dimana letak Tugu Army. Aku baru dan tidak tahu dimana letaknya"); getch();
	
	puts("\n======================================================================================================================");
	puts("\nTempat terakhir, Tugu Army");
	puts("======================================================================================================================\n");
	getch();
	
	puts("\nTerdapat jejak sandal kanan di tkp, ukurannya hampir sama dengan ukuran sandal Gamer.");
	puts("Alibi Gamer: Aku memakai kedua sendalku dan membuat permohonan di Tugu Army kemudian kembali.");
}
